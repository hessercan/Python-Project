import os

foundFiles = []
foundFolders = []

def findFiles(pattern, path, ignorecase, recursive):
    fileList = os.listdir(path)
    global foundFiles
    # foundFiles = []

    for file in fileList:
        absPath = os.path.join(path,file)

        if os.path.isdir(absPath) and recursive:
            findFiles(pattern,absPath,ignorecase,recursive)
        elif os.path.isfile(absPath):
            if ignorecase:
                if pattern.lower() in file.lower():
                    foundFiles.append(absPath)
            else:
                if pattern in file:
                    foundFiles.append(absPath)

    return foundFiles

def findFolders(pattern, path, ignorecase, recursive):
        fileList = os.listdir(path)
        global foundFolders
        # foundFolders = []

        for file in fileList:
            absPath = os.path.join(path,file)

            # Iterates recursive functionality
            if os.path.isdir(absPath) and recursive:
                findFolders(pattern,absPath,ignorecase,recursive)

            if os.path.isdir(absPath):
                if ignorecase:
                    if pattern.lower() in file.lower():
                        foundFolders.append(absPath)
                else:
                    if pattern in file:
                        foundFolders.append(absPath)

        # print(foundFiles)
        return foundFolders

def clearFind():
    global foundFiles
    global foundFolders
    foundFiles.clear()
    foundFolders.clear()

def printUsage():
    print("When Searching multiple patterns, you must clear the results using clearFind()")
    print("Usage: Pattern, Path, Case Sensitive, Recursive")

if __name__ == '__main__':
    printUsage()
